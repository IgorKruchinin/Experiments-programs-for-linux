 #pragma once

class ExcelManager {

};
