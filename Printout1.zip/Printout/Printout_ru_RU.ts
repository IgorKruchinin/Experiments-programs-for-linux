<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>PrintoutMainWin</name>
    <message>
        <location filename="printoutmainwin.ui" line="14"/>
        <source>PrintoutMainWin</source>
        <translation type="unfinished">Распечатка: главное окно</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="51"/>
        <source>Open Excel file</source>
        <translation type="unfinished">Открыть файл Excel</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="63"/>
        <source>Export to Excel</source>
        <translation type="unfinished">Экспорт в файл Excel</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="75"/>
        <source>Fill into table</source>
        <translation type="unfinished">Подставить из таблицы</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="92"/>
        <source>Rheostatic Tests</source>
        <translation type="unfinished">Реостатные испытания</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="111"/>
        <source>Date:</source>
        <translation type="unfinished">Дата:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="132"/>
        <source>Series:</source>
        <translation type="unfinished">Серия:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="153"/>
        <source>Number:</source>
        <translation type="unfinished">Номер:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="177"/>
        <source>Section:</source>
        <translation type="unfinished">Секция:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="198"/>
        <source>Repair:</source>
        <translation type="unfinished">Ремонт:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="223"/>
        <source>Tests type:</source>
        <translation type="unfinished">Вид испытаний:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="248"/>
        <source>Power NM:</source>
        <translation type="unfinished">Мощность НР:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="269"/>
        <source>VSH1 on/off:</source>
        <translation type="unfinished">ВШ1 вкл/выкл:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="290"/>
        <source>Supercharging, atm:</source>
        <translation type="unfinished">Наддув, атм:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="315"/>
        <source>Power EM:</source>
        <translation type="unfinished">Мощность АР:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="336"/>
        <source>VSH2 on/off:</source>
        <translation type="unfinished">ВШ2 вкл/выкл:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="357"/>
        <source>Time, h:</source>
        <translation type="unfinished">Время, ч:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="395"/>
        <source>Fuel consuption, l:</source>
        <translation type="unfinished">Расход топлива, л:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="433"/>
        <source>Notes:</source>
        <translation type="unfinished">Замечания:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="471"/>
        <source>Master r/t:</source>
        <translation type="unfinished">Мастер р/и:</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="509"/>
        <source>Clear</source>
        <translation type="unfinished">Очистить</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="521"/>
        <source>Save</source>
        <translation type="unfinished">Сохранить</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="533"/>
        <source>Print</source>
        <translation type="unfinished">Печать</translation>
    </message>
    <message>
        <location filename="printoutmainwin.ui" line="540"/>
        <source>Show print dialog</source>
        <translation type="unfinished">Показать выбор принтера и параметры печати</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Date</source>
        <translation type="unfinished">Дата</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Series</source>
        <translation type="unfinished">Серия</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Number</source>
        <translation type="unfinished">Номер</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Section</source>
        <translation type="unfinished">Секция</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Repair</source>
        <translation type="unfinished">Ремонт</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Tests type</source>
        <translation type="unfinished">Вид испытаний</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Power NM</source>
        <translation type="unfinished">Мощность НР</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Power EM</source>
        <translation type="unfinished">Мощность АР</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>VSH1</source>
        <translation type="unfinished">ВШ1</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>VSH2</source>
        <translation type="unfinished">ВШ2</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Supercharging</source>
        <translation type="unfinished">Наддув</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Time</source>
        <translation type="unfinished">Время</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Fuel consuption</source>
        <translation type="unfinished">Расход топлива</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Notes</source>
        <translation type="unfinished">Замечания</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="19"/>
        <source>Master</source>
        <translation type="unfinished">Мастер</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="123"/>
        <location filename="printoutmainwin.cpp" line="129"/>
        <source>Excel file</source>
        <translation type="unfinished">Файл Excel</translation>
    </message>
    <message>
        <location filename="printoutmainwin.cpp" line="123"/>
        <location filename="printoutmainwin.cpp" line="129"/>
        <source>Excel files (*.xls *.xlsx *.csv)</source>
        <translation type="unfinished">Файлы Excel (*.xls *.xlsx *.csv)</translation>
    </message>
</context>
<context>
    <name>PrintoutTableDialog</name>
    <message>
        <location filename="printouttabledialog.ui" line="31"/>
        <source>Fill from table</source>
        <translation type="unfinished">Подставить из таблицы</translation>
    </message>
    <message>
        <location filename="printouttabledialog.ui" line="59"/>
        <source>Once date:</source>
        <translation type="unfinished">По одной дате:</translation>
    </message>
    <message>
        <location filename="printouttabledialog.ui" line="80"/>
        <location filename="printouttabledialog.ui" line="113"/>
        <location filename="printouttabledialog.ui" line="176"/>
        <location filename="printouttabledialog.ui" line="209"/>
        <source>Apply</source>
        <translation type="unfinished">Применить</translation>
    </message>
    <message>
        <location filename="printouttabledialog.ui" line="92"/>
        <source>Series:</source>
        <translation type="unfinished">По серии:</translation>
    </message>
    <message>
        <location filename="printouttabledialog.ui" line="125"/>
        <source>Number:</source>
        <translation type="unfinished">По номеру:</translation>
    </message>
    <message>
        <location filename="printouttabledialog.ui" line="146"/>
        <source>Date range:</source>
        <translation type="unfinished">По диапазону дат:</translation>
    </message>
    <message>
        <location filename="printouttabledialog.ui" line="188"/>
        <source>Section:</source>
        <translation type="unfinished">По секции:</translation>
    </message>
    <message>
        <location filename="printouttabledialog.ui" line="221"/>
        <source>Cancel the last filter</source>
        <translation type="unfinished">Сбросить последний фильтр</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="52"/>
        <source>ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="53"/>
        <source>Date</source>
        <translation type="unfinished">Дата</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="54"/>
        <source>Series</source>
        <translation type="unfinished">Серия</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="55"/>
        <source>Number</source>
        <translation type="unfinished">Номер</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="56"/>
        <source>Section</source>
        <translation type="unfinished">Секция</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="57"/>
        <source>Repair</source>
        <translation type="unfinished">Ремонт</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="58"/>
        <source>Tests type</source>
        <translation type="unfinished">Вид испытаний</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="59"/>
        <source>Normal mode power</source>
        <translation type="unfinished">Мощность НР</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="60"/>
        <source>Emergency mode power</source>
        <translation type="unfinished">Мощность АР</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="61"/>
        <source>VSH1</source>
        <translation type="unfinished">ВШ1</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="62"/>
        <source>VSH2</source>
        <translation type="unfinished">ВШ2</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="63"/>
        <source>Supercharging</source>
        <translation type="unfinished">Наддув</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="64"/>
        <source>Time</source>
        <translation type="unfinished">Время</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="65"/>
        <source>Notes</source>
        <translation type="unfinished">Замечания</translation>
    </message>
    <message>
        <location filename="printouttabledialog.cpp" line="66"/>
        <source>Master</source>
        <translation type="unfinished">Мастер</translation>
    </message>
</context>
</TS>
