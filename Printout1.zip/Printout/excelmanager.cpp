#include "excelmanager.h"

ExcelManager::ExcelManager() {
}
