#ifndef EXCELMANAGER_H
#define EXCELMANAGER_H
#include "xlsxdocument.h"
#include "xlsxchartsheet.h"
#include "xlsxcellrange.h"
#include "xlsxchart.h"
#include "xlsxrichstring.h"
#include "xlsxworkbook.h"
#include "api/Definitions.h"

class ExcelManager
{
    QXlsx::Document excel;
public:
    ExcelManager();
    void saveToExcel(Stirng path) {

    }
};

#endif // EXCELMANAGER_H
